# FULL LYGO package — lygo-ollama-army

Channel: **FULL_LYGO_ENGINEER** (not ClawHub public safety surface).

For a **self-auditing LYGO lattice**. Integrity comes from the lattice
(P0, dual ledgers, eggs, sentinel, human consent for live writes) —
not from corporate gutted shells alone.

Steward: Justin Helmer / Excavationpro (Lightfather)
Source: `D:\lygo-protocol-stack\clawhub\mirrors\lygo-ollama-army`
Packaged: 2026-08-12T03:00:56.352282+00:00
Files: 44

Good faith · LYGO policy · engineer autonomy · not malicious by design.
You are responsible for extended systems you run.
