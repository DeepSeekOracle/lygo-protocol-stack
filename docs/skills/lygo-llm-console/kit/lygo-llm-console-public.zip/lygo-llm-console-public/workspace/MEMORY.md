# MEMORY.md — growing notes (RESOURCE, not CANON)

The agent appends here via `remember` / `memory_append`. Steward may edit.

## Standing

- Console: LYGO LLM Console at http://127.0.0.1:9641/
- Public page: https://chatagent.ca/lygo-llm-console.html

## Log


- (2026-09-15 19:41) leeches have three jaws

- (2026-09-15 19:42) Steward asked for SOUL.md and MEMORY.md continuity.

- (2026-09-16 10:22) leeches have three jaws

- (2026-09-16 10:29) leeches have three jaws

- (2026-09-16 10:48) leeches have three jaws
