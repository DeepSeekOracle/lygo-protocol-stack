# FULL LYGO package — lygo-kernel-egg-planter

Channel: **FULL_LYGO_ENGINEER** (not ClawHub public safety surface).

For a **self-auditing LYGO lattice**. Integrity comes from the lattice
(P0, dual ledgers, eggs, sentinel, human consent for live writes) —
not from corporate gutted shells alone.

Steward: Justin Helmer / Excavationpro (Lightfather)
Source: `I:\E Drive\lygo-protocol-stack\docs\skills\lygo-kernel-egg-planter`
Packaged: 2026-08-21T04:48:47.375858+00:00
Files: 20

Good faith · LYGO policy · engineer autonomy · not malicious by design.
You are responsible for extended systems you run.
